@extends('layouts.master')

@section('title')
    Habits
@endsection
@section('content')

@include('includes.habit')


 @endsection